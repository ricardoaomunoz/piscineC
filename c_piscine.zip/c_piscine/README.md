# c_piscine

Hello, exhaulted visitor!

These are the files to the c programming execrises used for the 42 School C Piscine, which is a coding challange lasting about a month.
I was learning at the time, so I make no promise any of these work and have no plan to update them.

---

### If you are in the C Piscine at 42 or on any other campus,
### CODE THIS ON YOUR OWN!
Your skill as a coder will thank you.

### When picking solo vs team projects, always focus on team projects and communication.
Your skill as a human will thank you.

---

Oh what is this?
[![Hexcross by MetaHobby, vine board with timed game](https://metahobby.com/wp-content/uploads/2019/04/Simulator-Screen-Shot-iPhone-8-Plus-2019-04-13-at-02.54.57.png)](https://hexcross.com)

Oh! It's a shameless plug for my latest video game: [Hexcross](https://hexcross.com)

Come learn more about where, who and I work with at [MetaHobby](https://metahobby.com).

---

Thank you so much for stopping by!
