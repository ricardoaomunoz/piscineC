gcc -o ex01.out -Wall -Wextra -Werror ex00/ft_putchar.c ex01/ft_print_program_name.c
gcc -o ex02.out -Wall -Wextra -Werror ex00/ft_putchar.c ex02/ft_print_params.c
gcc -o ex03.out -Wall -Wextra -Werror ex00/ft_putchar.c ex03/ft_rev_params.c
gcc -o ex04.out -Wall -Wextra -Werror ex00/ft_putchar.c ex04/ft_sort_params.c
echo "EX01:"
./ex01.out
echo "EX02:"
./ex02.out well that is just great
echo "EX03:"
./ex03.out 0b 1a 2c 3k 4w 5a 6r 7d it see lets
echo "EX04:"
./ex04.out a 7 zxy bloop somethingelse 00sorted!
