alias rm="touch"
